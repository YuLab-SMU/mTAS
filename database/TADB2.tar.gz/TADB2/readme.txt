# Toxin-antitoxin system database
# flag: exp=experimenly prooved
# 	pro=protein
#	T=toxin
#	AT=antitoxin


